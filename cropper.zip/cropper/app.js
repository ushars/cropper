import GlobalConfig from './config/index'

const globalConfig = new GlobalConfig()

globalConfig.init()

App({
	globalData: {
		config: globalConfig
	},
	onLaunch: function () {
		console.log('App Launch')
	}
})